﻿using System;

namespace RentCarApplication
{

    class Program : kisiselBilgi
    {
        public static int odenecektutar = 0;
        static void Main(string[] args)

        {





            char t;
            string giris = "Merhaba araç kiralama şirketimize hos geldiniz";
            string bilgiformu = "Telefon numarası :\nMail adresi : \nTc kimlik numarası :\nIkamet Adresi : ";
            Console.WriteLine(giris);
            Console.WriteLine("Size ulasabilmemiz için doldurmanız gereken bilgileri sırayla giriniz");
            Console.WriteLine();
            Console.WriteLine(bilgiformu);

            kisiselBilgi.bilgi();





            Console.WriteLine("Bakiyenizi giriniz");
            int bakiye = (Convert.ToInt32(Console.ReadLine()));
            if (bakiye < 2000)
            {
                Console.WriteLine("2000 tl altı arabamız bulunmamaktadır.\nSistem kapanmıştır...");
                Environment.Exit(0);
            }
            else
            {

                while (true)
                {
                    const int cesit = 2;
                    Console.WriteLine("Arabalarımız " + cesit + " çeşittir. \nHangi çeşit araç kiralamak istiyorsunuz ?   (binek/ticari)");
                    string cevap = Console.ReadLine();
                    Console.WriteLine("");



                    if (cevap.Equals("ticari"))
                    {
                        ticariFiyatListesi();
                        ticariModel();
                        Console.WriteLine("Secmek istediginiz modelin numarasini yaziniz");
                        int cevap1 = (Convert.ToInt32(Console.ReadLine()));
                        switch (cevap1)
                        {
                            case 1:
                                Caddy();
                                Console.WriteLine("");
                                Console.WriteLine("Araci kiralamk istedigine emin misiniz ? (E/H)");
                                t = Convert.ToChar(Console.ReadLine());
                                if (t.Equals('e') || t.Equals('E'))
                                {
                                    Console.WriteLine("Kiraladiginiz araba modeli : Caddy\nHayirli olsun dikkatli surun iyi yolculuklar");
                                    odenecektutar = odenecektutar + 6000;
                                    Console.WriteLine("");
                                    Sigorta.sigoorta();
                                    Kasko.kaskooo();
                                    Environment.Exit(0);
                                }
                                else if (t.Equals('h') || t.Equals('H'))
                                {
                                    Console.WriteLine("Baska modellerimizze bakabiliriniz...");
                                    Console.WriteLine("");
                                }
                                else
                                {
                                    Console.WriteLine("Yanlis yazdiniz lutfen tekrar deneyin...");
                                }

                                break;

                            case 2:
                                Transporter();
                                Console.WriteLine("");
                                Console.WriteLine("Araci kiralamk istedigine emin misiniz ? (E/H)");
                                t = Convert.ToChar(Console.ReadLine());
                                if (t.Equals('e') || t.Equals('E'))
                                {
                                    Console.WriteLine("Kiraladiginiz araba modeli : Transporter\nHayirli olsun dikkatli surun iyi yolculuklar");
                                    odenecektutar = odenecektutar + 6300;
                                    Console.WriteLine("");
                                    Sigorta.sigoorta();
                                    Kasko.kaskooo();
                                    Environment.Exit(0);
                                }
                                else if (t.Equals('h') || t.Equals('H'))
                                {
                                    Console.WriteLine("Baska modellerimizze bakabiliriniz...");
                                    Console.WriteLine("");
                                }
                                else
                                {
                                    Console.WriteLine("Yanlis yazdiniz lutfen tekrar deneyin...");
                                }
                                break;


                            case 3:
                                Caravelle();
                                Console.WriteLine("");
                                Console.WriteLine("Araci kiralamk istedigine emin misiniz ? (E/H)");
                                t = Convert.ToChar(Console.ReadLine());
                                if (t.Equals('e') || t.Equals('E'))
                                {
                                    Console.WriteLine("Kiraladiginiz araba modeli : Caravelle\nHayirli olsun dikkatli surun iyi yolculuklar");
                                    odenecektutar = odenecektutar + 6800;
                                    Console.WriteLine("");
                                    Sigorta.sigoorta();
                                    Kasko.kaskooo();
                                    Environment.Exit(0);
                                }
                                else if (t.Equals('h') || t.Equals('H'))
                                {
                                    Console.WriteLine("Baska modellerimizze bakabiliriniz...");
                                    Console.WriteLine("");
                                }
                                else
                                {
                                    Console.WriteLine("Yanlis yazdiniz lutfen tekrar deneyin...");
                                }
                                break;

                            case 4:
                                Crafter();
                                Console.WriteLine("");
                                Console.WriteLine("Araci kiralamk istedigine emin misiniz ? (E/H)");
                                t = Convert.ToChar(Console.ReadLine());
                                if (t.Equals('e') || t.Equals('E'))
                                {
                                    Console.WriteLine("Kiraladiginiz araba modeli : Crafter\nHayirli olsun dikkatli surun iyi yolculuklar");
                                    odenecektutar = odenecektutar + 7000;
                                    Console.WriteLine("");
                                    Sigorta.sigoorta();
                                    Kasko.kaskooo();
                                    Environment.Exit(0);
                                }
                                else if (t.Equals('h') || t.Equals('H'))
                                {
                                    Console.WriteLine("Baska modellerimizze bakabiliriniz...");
                                    Console.WriteLine("");
                                }
                                else
                                {
                                    Console.WriteLine("Yanlis yazdiniz lutfen tekrar deneyin...");
                                }
                                break;

                        }
                    }

                    else if (cevap.Equals("binek"))
                    {
                        char p;
                        binekFiyatListesi();
                        binekModel();
                        Console.WriteLine("Secmek istediginiz modelin numarasini yaziniz");
                        int yanit = (Convert.ToInt32(Console.ReadLine()));
                        switch (yanit)
                        {
                            case 1:

                                polo();
                                Console.WriteLine("");
                                Console.WriteLine("Araci kiralamk istedigine emin misiniz ? (E/H)");
                                p = Convert.ToChar(Console.ReadLine());
                                if (p.Equals('e') || p.Equals('E'))
                                {
                                    Console.WriteLine("Kiraladiginiz araba modeli : Polo\nHayirli olsun dikkatli surun iyi yolculuklar");
                                    odenecektutar = odenecektutar + 2000;
                                    Console.WriteLine("");
                                    Sigorta.sigoorta();
                                    Kasko.kaskooo();
                                    Environment.Exit(0);
                                }
                                else if (p.Equals('h') || p.Equals('H'))
                                {
                                    Console.WriteLine("Baska modellerimizze bakabiliriniz...");
                                    Console.WriteLine("");
                                }
                                else
                                {
                                    Console.WriteLine("Yanlis yazdiniz lutfen tekrar deneyin...");
                                }
                                break;


                            case 2:

                                golf();
                                Console.WriteLine("");
                                Console.WriteLine("Araci kiralamk istedigine emin misiniz ? (E/H)");
                                p = Convert.ToChar(Console.ReadLine());
                                if (p.Equals('e') || p.Equals('E'))
                                {
                                    Console.WriteLine("Kiraladiginiz araba modeli : golf\nHayirli olsun dikkatli surun iyi yolculuklar");
                                    odenecektutar = odenecektutar + 3500;
                                    Console.WriteLine("");
                                    Sigorta.sigoorta();
                                    Kasko.kaskooo();
                                    Environment.Exit(0);
                                }
                                else if (p.Equals('h') || p.Equals('H'))
                                {
                                    Console.WriteLine("Baska modellerimizze bakabiliriniz...");
                                    Console.WriteLine("");
                                }
                                else
                                {
                                    Console.WriteLine("Yanlis yazdiniz lutfen tekrar deneyin...");
                                }
                                break;


                            case 3:

                                tiguan();
                                Console.WriteLine("");
                                Console.WriteLine("Araci kiralamk istedigine emin misiniz ? (E/H)");
                                p = Convert.ToChar(Console.ReadLine());
                                if (p.Equals('e') || p.Equals('E'))
                                {
                                    Console.WriteLine("Kiraladiginiz araba modeli : Tiguan\nHayirli olsun dikkatli surun iyi yolculuklar");
                                    odenecektutar = odenecektutar + 4500;
                                    Console.WriteLine("");
                                    Sigorta.sigoorta();
                                    Kasko.kaskooo();

                                    Environment.Exit(0);
                                }
                                else if (p.Equals('h') || p.Equals('H'))
                                {
                                    Console.WriteLine("Baska modellerimizze bakabiliriniz...");
                                    Console.WriteLine("");
                                }
                                else
                                {
                                    Console.WriteLine("Yanlis yazdiniz lutfen tekrar deneyin...");
                                }
                                break;


                            case 4:

                                TRoc();
                                Console.WriteLine("");
                                Console.WriteLine("Araci kiralamk istedigine emin misiniz ? (E/H)");
                                p = Convert.ToChar(Console.ReadLine());
                                if (p.Equals('e') || p.Equals('E'))
                                {
                                    Console.WriteLine("Kiraladiginiz araba modeli : T-Roc\nHayirli olsun dikkatli surun iyi yolculuklar");
                                    odenecektutar = odenecektutar + 5000;
                                    Console.WriteLine("");
                                    Sigorta.sigoorta();
                                    Kasko.kaskooo();

                                    Environment.Exit(0);
                                }
                                else if (p.Equals('h') || p.Equals('H'))
                                {
                                    Console.WriteLine("Baska modellerimizze bakabiliriniz...");
                                    Console.WriteLine("");
                                }
                                else
                                {
                                    Console.WriteLine("Yanlis yazdiniz lutfen tekrar deneyin...");
                                }
                                break;


                            case 5:

                                passat();
                                Console.WriteLine("");
                                Console.WriteLine("Araci kiralamk istedigine emin misiniz ? (E/H)");
                                p = Convert.ToChar(Console.ReadLine());
                                if (p.Equals('e') || p.Equals('E'))
                                {
                                    Console.WriteLine("Kiraladiginiz araba modeli : Passat\nHayirli olsun dikkatli surun iyi yolculuklar");
                                    odenecektutar = odenecektutar + 7500;
                                    Console.WriteLine("");
                                    Sigorta.sigoorta();
                                    Kasko.kaskooo();

                                    Environment.Exit(0);
                                }
                                else if (p.Equals('h') || p.Equals('H'))
                                {
                                    Console.WriteLine("Baska modellerimizze bakabiliriniz...");
                                    Console.WriteLine("");
                                }
                                else
                                {
                                    Console.WriteLine("Yanlis yazdiniz lutfen tekrar deneyin...");
                                }
                                break;



                        }
                    }

                    else
                    {
                        Console.WriteLine("Yanlis cevap girdiniz lutfen tekrar deneyin...");
                    }
                }

            }

            Console.ReadKey();
        }




        public static void binekModel()
        {
            Console.WriteLine("Modellerimiz...");
            Console.WriteLine("1-Polo\n2-Golf\n3-Tiguan\n4-T-Roc\n5-Passat");
        }

        public static void polo()
        {
            Console.WriteLine("---POLO---");
            string bilgi5 = "Beygir : 90hp.\nUretim yili : 2016\nKapi sayisi : 5\nYakit tuketimi : 100/5L\nJant buyuklugu : 16";
            Console.WriteLine(bilgi5);
        }

        public static void golf()
        {
            Console.WriteLine("---GOLF---");
            string bilgi6 = "Beygir : 127hp.\nUretim yili : 2014\nKapi sayisi : 5\nYakit tuketimi : 100/4.8L\nJant buyuklugu : 18";
            Console.WriteLine(bilgi6);
        }
        public static void tiguan()
        {
            Console.WriteLine("---TIGUAN---");
            string bilgi7 = "Beygir : 140hp.\nUretim yili : 2015\nKapi sayisi : 5\nYakit tuketimi : 100/14L\nJant buyuklugu : 20";
            Console.WriteLine(bilgi7);
        }
        public static void TRoc()
        {
            Console.WriteLine("---T-Roc---");
            string bilgi8 = "Beygir : 160hp.\nUretim yili : 2017\nKapi sayisi : 5\nYakit tuketimi : 100/13L\nJant buyuklugu : 23";
            Console.WriteLine(bilgi8);
        }
        public static void passat()
        {
            Console.WriteLine("---PASSAT---");
            string bilgi9 = "Beygir : 310hp.\nUretim yili : 2022\nKapi sayisi : 5\nYakit tuketimi : 100/23.7L\nJant buyuklugu : 32";
            Console.WriteLine(bilgi9);
        }




        public static void binekFiyatListesi()
        {
            Console.WriteLine("Fiyatlarimiz aylik olarak guncellenmektedir...");
            string binekfiyatListesiBinek = ("Polo : 2000tl/ay\nGolf : 3500tl/ay\nTiguan : 4500tl/ay\nT-Roc : 5000tl/ay\nPassat : 7500tl/ay");
            Console.WriteLine(binekfiyatListesiBinek);
            Console.WriteLine("");
        }



        public static void ticariModel()
        {
            Console.WriteLine("Modellerimiz...");
            Console.WriteLine("1-Caddy\n2-Transporter\n3-Caravelle\n4-Crafter");
        }

        public static void ticariFiyatListesi()
        {
            Console.WriteLine("Fiyatlarimiz aylik olarak guncellenmektedir...");
            string fiyatListesiTicari = ("Caddy : 6000tl/ay\nTransporter : 6300tl/ay\nCaravelle : 6800/ay\nCrafter : 7000tl/ay");
            Console.WriteLine(fiyatListesiTicari);
            Console.WriteLine("");

        }

        public static void Caddy()
        {
            Console.WriteLine("---CADDY---");
            string bilgi = "Beygir : 90hp.\nUretim yili : 2020\nKapi sayisi : 5\nYakit tuketimi : 100/6L\nJant buyuklugu : 20";
            Console.WriteLine(bilgi);
        }

        public static void Transporter()
        {
            Console.WriteLine("---TRANSPORTER---");
            string bilgi1 = "Beygir : 120hp.\nUretim yili : 2021\nKapi sayisi : 4\nYakit tuketimi : 100/10L\nJant buyuklugu : 21";
            Console.WriteLine(bilgi1);
        }

        public static void Caravelle()
        {
            Console.WriteLine("---CARAVELLE---");
            string bilgi2 = "Beygir : 112hp.\nUretim yili : 2018\nKapi sayisi : 4\nYakit tuketimi : 100/7L\nJant buyuklugu : 19";
            Console.WriteLine(bilgi2);
        }
        public static void Crafter()
        {
            Console.WriteLine("---CRAFTER---");
            string bilgi3 = "Beygir : 150hp.\nUretim yili : 2019\nKapi sayisi : 6\nYakit tuketimi : 100/15L\nJant buyuklugu : 23";
            Console.WriteLine(bilgi3);
        }
    }
    struct finish {
        public static string txt = "Bizi tercih ettiginiz icin tesekkur ederiz...";
        
    }
}


    



















