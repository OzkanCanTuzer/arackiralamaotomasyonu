﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentCarApplication
{
    public class kisiselBilgi
    {
        
        public static void bilgi()
        {
            string telno = Console.ReadLine();
            string mail = Console.ReadLine();
            string tcno = Console.ReadLine();
            string adres = Console.ReadLine();
            Console.WriteLine("Bilgileriniz...");
            string txt = "Telefon Numaraniz :  " + telno + "\nMail Adresiniz : " + mail + "\nTC Numaraniz : " + tcno + "\nIkamet Adresiniz : " + adres;
            Console.WriteLine(txt);
        }




    }
}
