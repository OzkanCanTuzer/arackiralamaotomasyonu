﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentCarApplication
{
    
    class odeme 
    {
        
     
        private int ToplamOdecekTutar;
        public int toplamOdecekTutar
        {

        get { return ToplamOdecekTutar; }
            set
            {

                value = Program.odenecektutar ;
                {
                    
                    Console.WriteLine(value);
                    Console.WriteLine(" ");
                    Console.WriteLine(" ");
                    
                }
                
                

                

            }


      }
       
        





}
}
