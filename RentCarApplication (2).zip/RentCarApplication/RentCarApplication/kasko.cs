﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentCarApplication
{
   
    public class Kasko : Sigorta

    {
        
        public static void kaskooo()
        {
            if(kasko99!="a")
            secilenSigorta();
            
            Console.ReadKey();
        }

    }
    }
