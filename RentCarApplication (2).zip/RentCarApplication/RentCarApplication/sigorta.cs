﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RentCarApplication
{
    
    public class Sigorta 
    {
        public static string sigortaOlusan = " ",kasko99="";
        

        public static void sigoorta()
        {
            
            char c;
           

            string[] sigo = new string[3];
            sigo[0] = sigortaSirketleri.Allianz.ToString();
            sigo[1] = sigortaSirketleri.Sego.ToString();
            sigo[2] = sigortaSirketleri.Doga.ToString();
            Console.WriteLine("3 adet anlasmali sigorta sirketimizden ucretiyle yararlanabilirsiniz");
            Console.WriteLine("");
            for (int i = 0; i <= 2; i++)
            {

                Console.WriteLine((i + 1) + "-" + sigo[i]);
                Console.WriteLine("Bu sirketin sigorta ucreti aylik olarak : " + (700 - (i * 100)));
                

                Console.WriteLine("Bu sirket ile anlasma yapmak istiyor musunuz : (E/H)");
                c = Convert.ToChar(Console.ReadLine());
                if (c.Equals('e') || c.Equals('E'))
                {
                    Console.WriteLine("Anlasmaniz onaylanmistir odemeniz gereken tutar : " + (700 - (i * 100)));
                    Program.odenecektutar = (Program.odenecektutar + (700 - (i * 100)));
                    Console.WriteLine("");
                    Console.WriteLine("Kiraladiginiz araci kaskolatmak ister misiniz  ? (E/H)");
                    c = Convert.ToChar(Console.ReadLine());
                  
                    if (c.Equals('e')|| c.Equals('E'))
                    {
                        if (i == 0)
                        {
                            sigortaOlusan = "alianz kasko ";
                             
                        } else if (i == 1)
                        {
                            sigortaOlusan = "sego kasko ";
                        } else
                        {
                            sigortaOlusan = "doğa kasko ";
                        }
                        break;

                    }
                    else if (c.Equals('h') || c.Equals('H'))
                    {
                        kasko99 = "h";
                        break;
                    }
                    else
                    {
                        Console.WriteLine("Yanlis giriniz sistem kapandi...");
                        Environment.Exit(0);
                    }


                }
                else if (c.Equals('h') || c.Equals('H'))
                {
                    Console.WriteLine("Sizi baska sigorta sirketine yonlendiriyoruz.");
                    



                }
                else
                {
                    Console.WriteLine("yanlis yazdiniz lutfen tekrar deneyin");
                    break;
                }

            }

        }

        public static void secilenSigorta() 
        {
           
            if (kasko99 == "h")
            {
                Console.WriteLine("Kasko yapılmamıştır");

                Console.WriteLine("Odemeniz gereken tutar hesaplandi...");
                odeme para = new odeme();
                para.toplamOdecekTutar = 0;

                Console.ReadKey();
                Environment.Exit(0);
            }

            else
            {
                Console.WriteLine("Kaskonuz da " + sigortaOlusan + " firması tarafından yapılmıştır.");
                Console.WriteLine("Odemeniz gereken tutar hesaplandi...");
                odeme para = new odeme();
                para.toplamOdecekTutar = 0;

                Console.ReadKey();
            }
        }

    }
}
